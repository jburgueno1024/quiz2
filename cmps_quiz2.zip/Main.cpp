#include <iostream>
#include <iomanip>
using namespace std;

int main() 
{
    //do you know this guy
	
	//init vars
    float taxr = 8.25;
    int small = 0;
    int med = 0;
    int large = 0;
    double ts = 0;
    double tm = 0;
    double tl = 0;
    	
	// VV Get input from user VV
	
    //did you break in and leave this guy on my property
    cout << "--Place Your Order--\n-Small: $2.25\n-Medium: $3.00\n-Large: $3.75\n";
    
    //this guys been going nuts
    cout << "\nSmall Coffees to go: ";
    cin >> small;
    cout << small;
    
    //he freaked out my kids
    cout << "\nMedium Coffees to go: ";
    cin >> med;
    cout << med;
    
    //my wife is in hysterics she doesn't know what the hell is going on
    cout << "\nLarge Coffees to go: ";
    cin >> large;
    cout << large;
    
    //i had to take a day off work just to bring him back
    cout << "\n \nTax Rate (Default: 8.25): ";
    cin >> taxr;
    cout << setprecision(2) << taxr;
	
	//run some numbers
    
    ts = (small*2.25);
    tm = (med+3.00);
    tl = (large*3.75);
    
    float yeah = (ts+tm+tl);
    float naw = yeah*(taxr/100);
    float what = yeah+naw;
    
	
	//the output, yippee
    cout << "\n==Receipt==\n";
    
    cout << "\nSmall Coffee (" << small << " x $2.25): $" << setprecision(3) << showpoint << ts << endl;
    cout << "Medium Coffee (" << small << " x 3.00): $" << setprecision(3) << showpoint << tm << endl;
    cout << "Large Coffee (" << small << " x 3.75): $" << setprecision(4) << showpoint << tl << endl;
    
    cout << "\n----\n";
    cout << setw(30) << setfill('.') << left << "Subtotal" << "$" << fixed << setprecision(2) << showpoint << yeah << endl;
    cout << setw(30) << setfill('.') << left << "Tax" << "$" << fixed << setprecision(2) << showpoint << naw << endl;
    cout << "----\n";
    cout << setw(30) << setfill('.') << left << "Total" << "$" << fixed << setprecision(2) << showpoint << what << endl;
    return 0;
}